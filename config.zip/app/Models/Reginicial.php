<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reginicial extends Model
{
    protected $table = 'regisusu';
    protected $primaryKey = 'id';//tiene que hacer referencia a la llave primaria  
}
